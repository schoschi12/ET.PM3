var searchData=
[
  ['last_5fstate_0',['last_state',['../main_8c.html#a1e551bef5a7a497b3044886fe2e56b59',1,'main.c']]],
  ['line1_1',['line1',['../struct_m_e_n_u__entry__t.html#ae1acd6e390dd5194d11208034acb8d91',1,'MENU_entry_t']]],
  ['line2_2',['line2',['../struct_m_e_n_u__entry__t.html#a94cbcf18d647f9987b421714c2dc5147',1,'MENU_entry_t']]]
];
