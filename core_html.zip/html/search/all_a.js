var searchData=
[
  ['n_5fpoints_0',['n_points',['../distance_8c.html#a9e9f5e81be9055b77cad529a7609e195',1,'distance.c']]],
  ['new_5fstate_1',['new_state',['../main_8c.html#a31bd71b2bc6a0ee2d805447b432114eb',1,'main.c']]]
];
