var searchData=
[
  ['initiate_5fshutdown_0',['initiate_shutdown',['../main_8c.html#afa48a38a8de8c1db68965784d41736c8',1,'main.c']]]
];
