var searchData=
[
  ['get_5fadc_5fnums_0',['get_ADC_NUMS',['../measuring_8h.html#a0a03a8156d97779343c341d786c0e365',1,'get_ADC_NUMS(void):&#160;measuring.c'],['../measuring_8c.html#a0a03a8156d97779343c341d786c0e365',1,'get_ADC_NUMS(void):&#160;measuring.c']]],
  ['get_5fadc_5fsamples_1',['get_ADC_samples',['../measuring_8h.html#a52e98955c64c42add7a415a6514ec589',1,'get_ADC_samples(void):&#160;measuring.c'],['../measuring_8c.html#a52e98955c64c42add7a415a6514ec589',1,'get_ADC_samples(void):&#160;measuring.c']]],
  ['gyro_5fdisable_2',['gyro_disable',['../main_8c.html#a9506db1724e530dd11bccbdd8968998f',1,'main.c']]]
];
