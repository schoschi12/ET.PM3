var searchData=
[
  ['text_5fcolor_0',['text_color',['../struct_m_e_n_u__entry__t.html#aecbba4786b2fa7dd9667472c1b260132',1,'MENU_entry_t']]],
  ['timer_5fvalue_5fms_1',['timer_value_ms',['../main_8c.html#a5be5cb321b3cb99868ea12f6b37fcddd',1,'main.c']]]
];
