var searchData=
[
  ['dac_5factive_0',['DAC_active',['../measuring_8h.html#a69a35c5e5ae036f9089962dbc385aa71',1,'DAC_active():&#160;measuring.c'],['../measuring_8c.html#a69a35c5e5ae036f9089962dbc385aa71',1,'DAC_active():&#160;measuring.c']]],
  ['dac_5fincrement_1',['DAC_increment',['../measuring_8h.html#a892bfc2635d9b39cbeadd1f61d43ddd8',1,'DAC_increment(void):&#160;measuring.c'],['../measuring_8c.html#a892bfc2635d9b39cbeadd1f61d43ddd8',1,'DAC_increment(void):&#160;measuring.c']]],
  ['dac_5finit_2',['DAC_init',['../measuring_8h.html#a4500c15ee6b13637e00fd6b901b60224',1,'DAC_init(void):&#160;measuring.c'],['../measuring_8c.html#a4500c15ee6b13637e00fd6b901b60224',1,'DAC_init(void):&#160;measuring.c']]],
  ['dac_5freset_3',['DAC_reset',['../measuring_8h.html#a0ec0c70d77844e92e6b1862ab7fc7fb8',1,'DAC_reset(void):&#160;measuring.c'],['../measuring_8c.html#a0ec0c70d77844e92e6b1862ab7fc7fb8',1,'DAC_reset(void):&#160;measuring.c']]],
  ['dac_5fsample_4',['DAC_sample',['../measuring_8c.html#a8da5353c93f5798cf6c95956418a2210',1,'measuring.c']]],
  ['dispay_5fcurrent_5',['dispay_current',['../main_8c.html#abfce598ae1a5fd1cd4f563601d13890c',1,'main.c']]],
  ['distance_6',['distance',['../distance_8c.html#a06f14a9abd47b91465f895d5259cdc1b',1,'distance.c']]],
  ['distance_2ec_7',['distance.c',['../distance_8c.html',1,'']]],
  ['distance_2eh_8',['distance.h',['../distance_8h.html',1,'']]],
  ['distancelut_9',['distanceLUT',['../distance_8c.html#a2e39fb36a676f5551ed8aeab8a908cf8',1,'distance.c']]],
  ['dma2_5fstream1_5firqhandler_10',['DMA2_Stream1_IRQHandler',['../measuring_8c.html#adab6f3e22e90bd5b1ceebb98022abdf2',1,'measuring.c']]],
  ['dma2_5fstream3_5firqhandler_11',['DMA2_Stream3_IRQHandler',['../measuring_8c.html#a877135f6494d6923d6f6ec32d75d9eeb',1,'measuring.c']]],
  ['dma2_5fstream4_5firqhandler_12',['DMA2_Stream4_IRQHandler',['../measuring_8c.html#a295198ed574625d416158a5fc54205ea',1,'measuring.c']]],
  ['documenting_20firmware_13',['Documenting Firmware',['../documenting.html',1,'']]],
  ['documenting_2edox_14',['documenting.dox',['../documenting_8dox.html',1,'']]],
  ['draw_5farrow_15',['draw_arrow',['../distance_8h.html#ac7889be3035035f71a3d72b999c94ae8',1,'draw_arrow(uint16_t direction, uint16_t x_pos, uint16_t y_pos):&#160;distance.c'],['../distance_8c.html#ac7889be3035035f71a3d72b999c94ae8',1,'draw_arrow(uint16_t direction, uint16_t x_pos, uint16_t y_pos):&#160;distance.c']]]
];
