var searchData=
[
  ['tim_5fclock_0',['TIM_CLOCK',['../measuring_8c.html#a8f1900825debd6a99026eb55d9998131',1,'measuring.c']]],
  ['tim_5fprescale_1',['TIM_PRESCALE',['../measuring_8c.html#ad3224fe94be10ed1c61870bd1d22b86d',1,'measuring.c']]],
  ['tim_5ftop_2',['TIM_TOP',['../measuring_8c.html#a00237ed21338f907db7d88aeb54fecf2',1,'measuring.c']]]
];
