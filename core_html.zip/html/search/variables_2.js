var searchData=
[
  ['correction_0',['correction',['../distance_8c.html#a0de82eb7fa308eec612809ddc5469a16',1,'distance.c']]],
  ['cosine_1',['cosine',['../distance_8c.html#a5ba97e0f81fecfc53d5b2f0dc06b74ba',1,'distance.c']]]
];
