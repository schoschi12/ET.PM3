var searchData=
[
  ['calc_5fangle_0',['calc_angle',['../distance_8c.html#a6a2ca20d8838c78baaa23fe87ab3ff2e',1,'distance.c']]],
  ['calc_5fdistance_1',['calc_distance',['../distance_8c.html#af4d5fbc1888ee69ddb943dc7907ad50d',1,'distance.c']]],
  ['check_5ftime_2',['check_time',['../main_8c.html#a9e2b464746ce2af83ae0683a1f505349',1,'main.c']]]
];
