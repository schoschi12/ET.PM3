var searchData=
[
  ['cable_2dmonitor_20code_20documentation_0',['Cable-Monitor Code Documentation',['../index.html',1,'']]],
  ['calc_5fangle_1',['calc_angle',['../distance_8c.html#a6a2ca20d8838c78baaa23fe87ab3ff2e',1,'distance.c']]],
  ['calc_5fdistance_2',['calc_distance',['../distance_8c.html#af4d5fbc1888ee69ddb943dc7907ad50d',1,'distance.c']]],
  ['check_5ftime_3',['check_time',['../main_8c.html#a9e2b464746ce2af83ae0683a1f505349',1,'main.c']]],
  ['coding_20guidelines_4',['Coding Guidelines',['../coding_guidelines.html',1,'']]],
  ['coding_5fguidelines_2edox_5',['coding_guidelines.dox',['../coding__guidelines_8dox.html',1,'']]],
  ['correction_6',['correction',['../distance_8c.html#a0de82eb7fa308eec612809ddc5469a16',1,'distance.c']]],
  ['cosine_7',['cosine',['../distance_8c.html#a5ba97e0f81fecfc53d5b2f0dc06b74ba',1,'distance.c']]]
];
