var searchData=
[
  ['back_5fcolor_0',['back_color',['../struct_m_e_n_u__entry__t.html#a0fd107c268f85989486fd5e5aa6a538b',1,'MENU_entry_t']]]
];
